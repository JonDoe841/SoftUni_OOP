from project.fruit import Fruit

f = Fruit("banana", "2025-01-01")
print(f.name)
print(f.expiration_date)