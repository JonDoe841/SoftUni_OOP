from project.dog import Dog

d = Dog()
print(d.eat())
print(d.bark())